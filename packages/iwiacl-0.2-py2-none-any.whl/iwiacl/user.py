from .base import BaseAction, Types


class CreateUser(BaseAction):
    """
    Create a user.
    """
    namespace = 'user'
    version = 1
    method = 'post'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-n', '--name')
        parser.add_argument('-e', '--enabled', action='store_true', default=False)
        parser.add_argument('-t', '--tokens', type=Types.comma_list, default='',
                metavar='TOKEN[,TOKEN...]')
        parser.add_argument('-o', '--organisations', type=Types.comma_list, default='',
                metavar='ORG[,ORG...]')
        parser.add_argument('-p', '--permissions', type=Types.comma_list, default='',
                metavar='PERM[,PERM...]')
        parser.add_argument('-g', '--groups', type=Types.comma_list, default='',
                metavar='GROUP[,GROUP...]')
        parser.add_argument('-d', '--data', type=Types.b64_data, default="e30=") # default = {} b64 encoded

    def build_packet(self):
        args = self.args
        ret = {
            'name': args['name'],
            'permissions': args['permissions'],
            'groups': args['groups'],
            'tokens': args['tokens'],
            'enabled': args['enabled'],
            'organisations': args['organisations'],
        }
        if args['data']:
            ret['data'] = args['data']
        return ret


class ListUsers(BaseAction):
    """
    List one or many users
    """
    namespace = 'user'
    version = 1
    method = 'get'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-t', '--token',
                help='Return users with the given token.')

    def get_arg(self):
        return self.args.get('token')


class ChangeUser(BaseAction):
    namespace = 'user'
    version = 1
    method = 'put'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-t', '--token', required=True)
        parser.add_argument('-n', '--name')
        parser.add_argument('-e', '--enabled', type=Types.word_bool)
        parser.add_argument('-a', '--admin', type=Types.word_bool)

        parser.add_argument('--tokens', type=Types.comma_list, default='',
                metavar='TOKEN[,TOKEN...]')
        parser.add_argument('-o', '--organisations', type=Types.comma_list, default='',
                metavar='ORG[,ORG...]')
        parser.add_argument('-p', '--permissions', type=Types.comma_list, default='',
                metavar='PERM[,PERM...]')
        parser.add_argument('-g', '--groups', type=Types.comma_list, default='',
                metavar='GROUP[,GROUP...]')
        parser.add_argument('-d', '--data', type=Types.b64_data, default="e30=") # default = {} b64 encoded

    def get_arg(self):
        return self.args['token']

    def build_packet(self):
        args = self.args
        p = {
            'groups': args['groups'],
            'tokens': args['tokens'],
            'organisations': args['organisations'],
            'permissions': args['permissions'],
        }
        if args['data']:
            p['data'] = args['data']

        for prop in ('name','enabled','admin'):
            val = args.get(prop)
            if val is not None:
                p[prop] = val

        return p


class DeleteUser(BaseAction):
    namespace = 'user'
    version = 1
    method = 'delete'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-t', '--token', required=True)

    def get_arg(self):
        return self.args.get('token', None)
