from .base import BaseAction, Types

class ListGroups(BaseAction):
    namespace = 'group'
    version = 1
    method = 'get'


class CreateGroup(BaseAction):
    namespace = 'group'
    version = 1
    method = 'post'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-n', '--name')
        parser.add_argument('-p', '--permissions', type=Types.comma_list, default='',
                metavar='PERM[,PERM...]')
        parser.add_argument('-e', '--extra', type=Types.json, default='{}')

    def build_packet(self):
        args = self.args
        return {
            'name': args['name'],
            'permissions': args['permissions'],
            'extra_data': args['extra'],
        }

class ChangeGroup(BaseAction):
    """
    Change a group. Keyed by --id. You cannot change the name.
    """
    namespace = 'group'
    version = 1
    method = 'put'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-i', '--id')
        parser.add_argument('-p', '--permissions', type=Types.comma_list, default='',
                metavar='PERM[,PERM...]')
        parser.add_argument('-e', '--extra', type=Types.json, default='{}')

    def get_arg(self):
        return self.args.get('id')

    def build_packet(self):
        return {
            'permissions': self.args.get('permissions',[]),
            'extra_data': self.args['extra'],
        }

