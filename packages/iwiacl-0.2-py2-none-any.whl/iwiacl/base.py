import httplib

from itsdangerous import TimedSerializer, TimestampSigner
from base64 import b64decode
from json import loads

class Types(object):
    @staticmethod
    def comma_list(s):
        if not s:
            return []
        return s.split(",")

    @staticmethod
    def word_bool(s):
        """Turns 'Yes','y','yes','true','True' etc into a bool"""
        return s.lower() in ('yes','y','true')

    @staticmethod
    def b64_data(s):
        """Turns b64 encoded json dict into dict."""
        return loads(b64decode(s))

    @staticmethod
    def json(s):
        return loads(s)


class BaseAction(object):
    version = 0
    namespace = None
    method = 'post'

    @classmethod
    def build_options(cls, parser):
        """Build argparse options for the subcommand here."""
        pass

    def __init__(self, ap_args=None, **kwargs):
        if ap_args:
            self.args = dict(ap_args._get_kwargs())
        else:
            self.args = self._process_args(**kwargs)

        self.serializer = TimedSerializer(self.args['secret'])
        self.signer = TimestampSigner(self.args['secret'])

    def _process_args(self, host, port, secret, max_age=60, **kwargs):
        """Convert kwargs to args. Lazy way of checking we have them all"""
        kwargs['host'] = host
        kwargs['port'] = port
        kwargs['secret'] = secret
        kwargs['max_age'] = max_age
        return kwargs

    def get_arg(self):
        """Get the URL argument for the api.
        If this returns null it will not be used"""
        return None

    def get_url(self):
        url = '/v%(ver)s/%(ns)s/' % {
            'ver': self.version,
            'ns': self.namespace
        }

        arg = self.get_arg()
        if arg:
            url += '%s/' % arg
        return self.signer.sign(url)

    def run(self, **kwargs):
        self.args.update(kwargs)

        conn = httplib.HTTPConnection(self.args['host'], self.args['port'])
        args = {
            'method': self.method.upper(),
            'url': self.get_url(),
        }
        if args['method'] in ('POST','PUT'):
            args['body'] = self.serializer.dumps(self.build_packet())
            args['headers'] = {'Content-Type':'application/signed-json'}

        conn.request(**args)
        resp = conn.getresponse()

        if resp.status == 200:
            data = self.serializer.loads(resp.read(), max_age=self.args['max_age'])
            return data
        else:
            raise ValueError("Request returned HTTP %s." % resp.status)

    def build_packet(self):
        return {}

