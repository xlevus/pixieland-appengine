from .base import BaseAction

class CreatePermission(BaseAction):
    namespace = 'permission'
    version = 1
    method = 'post'

    @classmethod
    def build_options(cls, parser):
        parser.add_argument('-a', '--app', required=True)
        parser.add_argument('-e', '--environ', required=True)
        parser.add_argument('-m', '--module', required=True)
        parser.add_argument('-c', '--action', required=True)
        parser.add_argument('--help-text', default='')

    def build_packet(self):
        args = self.args
        return {
            'application': args['app'],
            'environment': args['environ'],
            'module': args['module'],
            'action': args['action'],
            'help_text': args['help_text']
        }


class ListPermissions(BaseAction):
    namespace = 'permission'
    version = 1
    method = 'get'



