Simple wrapper to use SendGrid SMTP API


